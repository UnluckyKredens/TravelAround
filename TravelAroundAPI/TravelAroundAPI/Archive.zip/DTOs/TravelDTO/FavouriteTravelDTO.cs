﻿using System;
namespace TravelAroundAPI.DTOs
{
	public class FavouriteTravelDTO
	{
		public int UserId { get; set; }
		public int TravelId { get; set; }
	}
}

