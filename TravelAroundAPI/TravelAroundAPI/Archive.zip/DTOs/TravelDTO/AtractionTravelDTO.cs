﻿using System;
namespace TravelAroundAPI.DTOs
{
	public class AtractionTravelDTO
	{
		public int AtractionId { get; set; }
		public int TravelId { get; set; }
    }
}

