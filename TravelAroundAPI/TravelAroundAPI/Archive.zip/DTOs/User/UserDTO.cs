﻿using System;
namespace TravelAroundAPI.DTOs
{
	public class UserDTO
	{

		public string Login { get; set; }
		public string Password { get; set; }
	}
}

