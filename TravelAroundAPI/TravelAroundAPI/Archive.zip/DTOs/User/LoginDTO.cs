﻿using System;
namespace TravelAroundAPI.DTOs
{
	public class LoginDTO
	{
        public string Login { get; set; }
        public string Password { get; set; }
    }
}

