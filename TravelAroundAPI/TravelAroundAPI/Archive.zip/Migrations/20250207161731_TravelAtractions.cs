﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TravelAroundAPI.Migrations
{
    public partial class TravelAtractions : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
