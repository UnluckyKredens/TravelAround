﻿using System;

    using System.Net.Http;
    using System.Text;
    using System.Text.Json;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Configuration;
    using TravelAroundAPI.DTOs;
    using TravelAroundAPI.DTOs.GPT;

namespace TravelAroundAPI.Services
{
    public class GPTService
    {
         readonly HttpClient _httpClient;
         readonly string _apiKey;

        public GPTService(IConfiguration configuration)
        {
            _httpClient = new HttpClient();
            _apiKey = configuration["OpenAI:ApiKey"];
        }

        public async Task<TravelGeneratedResponse> GenerateTravelDescription(TravelGenerationRequest request)
        {
            string prompt = $"Zaprojektuj opis podróży z {request.From} do {request.Destination} dla {request.Members} osób. Budżet: {request.Price} PLN. Podaj również atrakcje warte odwiedzenia.";

            var requestBody = new
            {
                model = "gpt-4",
                messages = new[]
                {
                new { role = "system", content = "Jesteś asystentem podróży i piszesz kreatywne opisy." },
                new { role = "user", content = prompt }
            },
                max_tokens = 500
            };

            var requestContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");

            var response = await _httpClient.PostAsync("https://api.openai.com/v1/chat/completions", requestContent);
            var responseString = await response.Content.ReadAsStringAsync();

            var gptResponse = JsonSerializer.Deserialize<ChatGPTResponse>(responseString);

            return new TravelGeneratedResponse
            {
                Description = gptResponse.Choices[0].Message.Content,
                Atractions = new List<AtractionDTO>()
        };
        }
    }

    public class ChatGPTResponse
    {
        public Choice[] Choices { get; set; }
    }

    public class Choice
    {
        public Message Message { get; set; }
    }

    public class Message
    {
        public string Role { get; set; }
        public string Content { get; set; }
    }

}

