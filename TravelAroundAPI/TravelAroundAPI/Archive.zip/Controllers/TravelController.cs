﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TravelAroundAPI.Data;
using TravelAroundAPI.DTOs;
using TravelAroundAPI.DTOs.GPT;
using TravelAroundAPI.DTOs.ReturnDTOs;
using TravelAroundAPI.Entities;
using TravelAroundAPI.Entities.Travel;
using TravelAroundAPI.Services;

[Route("api/[controller]")]
[ApiController]
public class TravelController : ControllerBase
{
    private readonly DataContext _context;
    private readonly GPTService _gptService;

    public TravelController(DataContext context, GPTService gpTService)
    {
        _context = context;
        _gptService = gpTService;
    }

    [HttpPost("Add")]
    public async Task<IActionResult> AddTravel(TravelDTO travel)
    {
        var model = new Travel
        {
            Name = travel.Name,
            ImageUrl = travel.ImageUrl,
            Price = travel.Price,
            Destination = travel.Destination,
            From = travel.From,
            Members = travel.Members,
            Description = travel.Description
        };

        _context.Travels.Add(model);
        await _context.SaveChangesAsync();
        return Ok();
    }

    [HttpGet]
    public async Task<IActionResult> GetAllTravels()
    {
        var travels = await _context.Travels
            .Include(t => t.TravelAtractions)
            .ThenInclude(ta => ta.Atraction)
            .ToListAsync();

        var travelDtos = travels.Select(t => new TravelWithAtractionsDTO
        {
            TravelId = t.Id,
            ImageUrl = t.ImageUrl,
            Name = t.Name,
            Price = t.Price,
            Destination = t.Destination,
            From = t.From,
            Members = t.Members,
            Description = t.Description,
            Likes = t.Likes,
            Atractions = t.TravelAtractions
                .Select(ta => new AtractionDTO
                {
                    Id = ta.Atraction.Id,
                    Name = ta.Atraction.Name,
                    Price = ta.Atraction.Price,
                    Destination = ta.Atraction.Destination,
                    Description = ta.Atraction.Description,
                    ImageUrl = ta.Atraction.ImageUrl
                })
                .ToList()
        }).ToList();

        return Ok(travelDtos);
    }

    [HttpGet("destination")]
    public async Task<ActionResult<IEnumerable<TravelWithAtractionsDTO>>> GetTravelsByDestination(string destination)
    {
        if (string.IsNullOrEmpty(destination))
            return BadRequest("Destination parameter is required.");

        var travels = await _context.Travels
            .Where(t => t.Destination.Contains(destination))
            .Include(t => t.TravelAtractions)
            .ThenInclude(ta => ta.Atraction)
            .ToListAsync();

        if (!travels.Any()) return NotFound("No travels found for the given destination.");

        var travelDtos = travels.Select(t => new TravelWithAtractionsDTO
        {
            TravelId = t.Id,
            ImageUrl = t.ImageUrl,
            Name = t.Name,
            Price = t.Price,
            Destination = t.Destination,
            From = t.From,
            Members = t.Members,
            Description = t.Description,
            Likes = t.Likes,
            Atractions = t.TravelAtractions
                .Select(ta => new AtractionDTO
                {
                    Id = ta.Atraction.Id,
                    Name = ta.Atraction.Name,
                    Price = ta.Atraction.Price,
                    Destination = ta.Atraction.Destination,
                    Description = ta.Atraction.Description,
                    ImageUrl = ta.Atraction.ImageUrl
                })
                .ToList()
        }).ToList();

        return Ok(travelDtos);
    }



    [HttpGet("{id}")]
    public async Task<ActionResult<TravelAtraction>> GetTravelById(int id)
    {
        var travel = await _context.Travels
         .Include(t => t.TravelAtractions)
         .ThenInclude(ta => ta.Atraction) // Pobieramy atrakcje
         .FirstOrDefaultAsync(t => t.Id == id);

        if (travel == null) return NotFound("Travel not found.");

        var travelDto = new TravelWithAtractionsDTO
        {
            TravelId = travel.Id,
            ImageUrl = travel.ImageUrl,
            Name = travel.Name,
            Price = travel.Price,
            Destination = travel.Destination,
            From = travel.From,
            Members = travel.Members,
            Description = travel.Description,
            Likes = travel.Likes,
            Atractions = travel.TravelAtractions
                .Select(ta => new AtractionDTO
                {
                    Id = ta.Atraction.Id,
                    Name = ta.Atraction.Name,
                    Price = ta.Atraction.Price,
                    Destination = ta.Atraction.Destination,
                    Description = ta.Atraction.Description,
                    ImageUrl = ta.Atraction.ImageUrl
                })
                .ToList()
        };

        return Ok(travelDto);
    }

    [HttpGet("top")]
    public async Task<ActionResult<IEnumerable<TravelWithAtractionsDTO>>> GetTopTravels()
    {
        var travels = await _context.Travels
            .OrderByDescending(t => t.Likes)
            .Take(5)
            .Include(t => t.TravelAtractions)
            .ThenInclude(ta => ta.Atraction)
            .ToListAsync();

        var travelDtos = travels.Select(t => new TravelWithAtractionsDTO
        {
            TravelId = t.Id,
            ImageUrl = t.ImageUrl,
            Name = t.Name,
            Price = t.Price,
            Destination = t.Destination,
            From = t.From,
            Members = t.Members,
            Description = t.Description,
            Likes = t.Likes,
            Atractions = t.TravelAtractions
                .Select(ta => new AtractionDTO
                {
                    Id = ta.Atraction.Id,
                    Name = ta.Atraction.Name,
                    Price = ta.Atraction.Price,
                    Destination = ta.Atraction.Destination,
                    Description = ta.Atraction.Description,
                    ImageUrl = ta.Atraction.ImageUrl
                })
                .ToList()
        }).ToList();

        return Ok(travelDtos);
    }


    [HttpPost("generate")]
    public async Task<ActionResult<TravelGeneratedResponse>> GenerateTravel([FromBody] TravelGenerationRequest request)
    {
        var generatedTravel = await _gptService.GenerateTravelDescription(request);
        return Ok(generatedTravel);
    }

    // ✅ 2. Zapisywanie podróży do bazy
    [HttpPost("save")]
    public async Task<IActionResult> SaveGeneratedTravel([FromBody] TravelAroundAPI.Entities.Travel.TravelWithAtractions travel)
    {
        _context.Travels.Add(travel);
        await _context.SaveChangesAsync();
        return Ok(new { message = "Travel saved successfully!" });
    }

    // ✅ 3. Porównanie atrakcji z bazą
    [HttpGet("compare/{id}")]
    public async Task<ActionResult<string>> CompareGeneratedAttractions(int id)
    {
        var travel = await _context.Travels
            .Include(t => t.Atractions)
            .FirstOrDefaultAsync(t => t.Id == id);

        if (travel == null) return NotFound("Travel not found");

        foreach (var atraction in travel.Atractions)
        {
            var existingAtraction = await _context.Atractions.FirstOrDefaultAsync(a => a.Name == atraction.Name);
            if (existingAtraction != null)
            {
                return Ok($"Existing attraction found: {existingAtraction.Name}. Suggested description: {existingAtraction.Description}");
            }
        }

        return Ok("No matching attractions found.");
    }

    [HttpGet("generate-attractions/{city}")]
    public async Task<ActionResult<List<AtractionDTO>>> GenerateAttractionsForCity(string city)
    {
        string prompt = $"Wymień atrakcje warte odwiedzenia w {city}. Podaj 5 najciekawszych miejsc.";

        var requestBody = new
        {
            model = "gpt-4",
            messages = new[]
            {
                new { role = "system", content = "Jesteś przewodnikiem turystycznym." },
                new { role = "user", content = prompt }
            },
            max_tokens = 300
        };
        var requestContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

        _gptService._httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_gptService._apiKey}");

        var response = await _gptService._httpClient.PostAsync("https://api.openai.com/v1/chat/completions", requestContent);
        var responseString = await response.Content.ReadAsStringAsync();

        var gptResponse = JsonSerializer.Deserialize<ChatGPTResponse>(responseString);

        return Ok(new List<AtractionDTO>
        {
            new AtractionDTO { Name = gptResponse.Choices[0].Message.Content }
        });
    }

}
